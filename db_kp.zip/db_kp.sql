-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 25 Jul 2018 pada 04.25
-- Versi Server: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_kp`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tensor`
--

CREATE TABLE IF NOT EXISTS `tensor` (
`id_tensor` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nama_label` varchar(100) NOT NULL,
  `nose` float NOT NULL,
  `leftEye` float NOT NULL,
  `rightEye` float NOT NULL,
  `leftEar` float NOT NULL,
  `rightEar` float NOT NULL,
  `leftShoulder` float NOT NULL,
  `rightShoulder` float NOT NULL,
  `leftElbow` float NOT NULL,
  `rightElbow` float NOT NULL,
  `leftWrist` float NOT NULL,
  `rightWrist` float NOT NULL,
  `leftHip` float NOT NULL,
  `rightHip` float NOT NULL,
  `leftKnee` float NOT NULL,
  `rightKnee` float NOT NULL,
  `leftAnkle` float NOT NULL,
  `rightAnkle` float NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel `tensor`
--

INSERT INTO `tensor` (`id_tensor`, `time`, `nama_label`, `nose`, `leftEye`, `rightEye`, `leftEar`, `rightEar`, `leftShoulder`, `rightShoulder`, `leftElbow`, `rightElbow`, `leftWrist`, `rightWrist`, `leftHip`, `rightHip`, `leftKnee`, `rightKnee`, `leftAnkle`, `rightAnkle`) VALUES
(1, '2018-07-05 01:37:04', 'tidur', 0.2322, 0.2321, 0.2329, 0.2328, 0.23266, 0.2327, 0.23, 0.2324, 0.239, 0.2329, 0.2328, 0.2357, 0.238, 0.23221, 0.2326, 0.232, 0.2322),
(2, '2018-07-05 06:57:23', 'duduk', 0.995, 0.99855, 0.9955, 0.9995, 0.9945, 0.975, 0.9985, 0.9953, 0.9956, 0.9957, 0.9958, 0.995, 0.9925, 0.99445, 0.98895, 0.99599, 0.99588);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tensordata`
--

CREATE TABLE IF NOT EXISTS `tensordata` (
`id` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `score` float NOT NULL,
  `part` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data untuk tabel `tensordata`
--

INSERT INTO `tensordata` (`id`, `time`, `score`, `part`) VALUES
(1, '2018-07-19 15:22:51', 0.501073, 'nose'),
(2, '2018-07-19 15:22:52', 0.504299, 'leftEye'),
(3, '2018-07-19 15:22:52', 0.500809, 'rightEye'),
(4, '2018-07-19 15:22:52', 0.500661, 'leftEar'),
(5, '2018-07-19 15:22:52', 0.498802, 'rightEar'),
(6, '2018-07-19 15:22:52', 0.526892, 'leftShoulder'),
(7, '2018-07-19 15:22:52', 0.525239, 'rightShoulder'),
(8, '2018-07-19 15:22:52', 0.52455, 'leftElbow'),
(9, '2018-07-19 15:22:52', 0.524568, 'rightElbow'),
(10, '2018-07-19 15:22:52', 0.524224, 'leftWrist'),
(11, '2018-07-19 15:22:52', 0.523196, 'rightWrist'),
(12, '2018-07-19 15:22:52', 0.528468, 'leftHip'),
(13, '2018-07-19 15:22:52', 0.528566, 'rightHip'),
(14, '2018-07-19 15:22:52', 0.526127, 'leftKnee'),
(15, '2018-07-19 15:22:52', 0.529348, 'rightKnee'),
(16, '2018-07-19 15:22:52', 0.529422, 'leftAnkle'),
(17, '2018-07-19 15:22:52', 0.530631, 'rightAnkle');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tensor`
--
ALTER TABLE `tensor`
 ADD PRIMARY KEY (`id_tensor`);

--
-- Indexes for table `tensordata`
--
ALTER TABLE `tensordata`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tensor`
--
ALTER TABLE `tensor`
MODIFY `id_tensor` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tensordata`
--
ALTER TABLE `tensordata`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
