-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 24 Jul 2018 pada 10.15
-- Versi Server: 5.6.20
-- PHP Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_kp`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tensor`
--

CREATE TABLE IF NOT EXISTS `tensor` (
`id_tensor` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nama_label` varchar(100) NOT NULL,
  `nose` float NOT NULL,
  `leftEye` float NOT NULL,
  `rightEye` float NOT NULL,
  `leftEar` float NOT NULL,
  `rightEar` float NOT NULL,
  `leftShoulder` float NOT NULL,
  `rightShoulder` float NOT NULL,
  `leftElbow` float NOT NULL,
  `rightElbow` float NOT NULL,
  `leftWrist` float NOT NULL,
  `rightWrist` float NOT NULL,
  `leftHip` float NOT NULL,
  `rightHip` float NOT NULL,
  `leftKnee` float NOT NULL,
  `rightKnee` float NOT NULL,
  `leftAnkle` float NOT NULL,
  `rightAnkle` float NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel `tensor`
--

INSERT INTO `tensor` (`id_tensor`, `time`, `nama_label`, `nose`, `leftEye`, `rightEye`, `leftEar`, `rightEar`, `leftShoulder`, `rightShoulder`, `leftElbow`, `rightElbow`, `leftWrist`, `rightWrist`, `leftHip`, `rightHip`, `leftKnee`, `rightKnee`, `leftAnkle`, `rightAnkle`) VALUES
(1, '2018-07-05 01:37:04', 'tidur', 0.2322, 0.2321, 0.2329, 0.2328, 0.23266, 0.2327, 0.23, 0.2324, 0.239, 0.2329, 0.2328, 0.2357, 0.238, 0.23221, 0.2326, 0.232, 0.2322),
(2, '2018-07-05 06:57:23', 'duduk', 0.995, 0.99855, 0.9955, 0.9995, 0.9945, 0.975, 0.9985, 0.9953, 0.9956, 0.9957, 0.9958, 0.995, 0.9925, 0.99445, 0.98895, 0.99599, 0.99588);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tensor`
--
ALTER TABLE `tensor`
 ADD PRIMARY KEY (`id_tensor`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tensor`
--
ALTER TABLE `tensor`
MODIFY `id_tensor` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
